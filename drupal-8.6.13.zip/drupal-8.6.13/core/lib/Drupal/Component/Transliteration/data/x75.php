<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zhui', 'ping', 'bian', 'zhou', 'zhen', 'Senchigura ', 'ci', 'ying', 'qi', 'xian', 'lou', 'di', 'ou', 'meng', 'zhuan', 'beng',
  0x10 => 'lin', 'zeng', 'wu', 'pi', 'dan', 'weng', 'ying', 'yan', 'gan', 'dai', 'shen', 'tian', 'tian', 'han', 'chang', 'sheng',
  0x20 => 'qing', 'shen', 'chan', 'chan', 'rui', 'sheng', 'su', 'shen', 'yong', 'shuai', 'lu', 'fu', 'yong', 'beng', 'feng', 'ning',
  0x30 => 'tian', 'you', 'jia', 'shen', 'zha', 'dian', 'fu', 'nan', 'dian', 'ping', 'ting', 'hua', 'ting', 'zhen', 'zai', 'meng',
  0x40 => 'bi', 'qi', 'liu', 'xun', 'liu', 'chang', 'mu', 'yun', 'fan', 'fu', 'geng', 'tian', 'jie', 'jie', 'quan', 'wei',
  0x50 => 'fu', 'tian', 'mu', 'duo', 'pan', 'jiang', 'wa', 'da', 'nan', 'liu', 'ben', 'zhen', 'chu', 'mu', 'mu', 'ce',
  0x60 => 'tian', 'gai', 'bi', 'da', 'zhi', 'e', 'qi', 'lue', 'pan', 'yi', 'fan', 'hua', 'she', 'yu', 'mu', 'jun',
  0x70 => 'yi', 'liu', 'she', 'die', 'chou', 'hua', 'dang', 'zhui', 'ji', 'wan', 'jiang', 'cheng', 'chang', 'tun', 'lei', 'ji',
  0x80 => 'cha', 'liu', 'die', 'tuan', 'lin', 'jiang', 'jiang', 'chou', 'pi', 'die', 'die', 'pi', 'jie', 'dan', 'shu', 'shu',
  0x90 => 'zhi', 'yi', 'ne', 'nai', 'ding', 'bi', 'jie', 'liao', 'gang', 'ge', 'jiu', 'zhou', 'xia', 'shan', 'xu', 'nue',
  0xA0 => 'li', 'yang', 'chen', 'you', 'ba', 'jie', 'jue', 'qi', 'xia', 'cui', 'bi', 'yi', 'li', 'zong', 'chuang', 'feng',
  0xB0 => 'zhu', 'pao', 'pi', 'gan', 'ke', 'ci', 'xue', 'zhi', 'dan', 'zhen', 'fa', 'zhi', 'teng', 'ju', 'ji', 'fei',
  0xC0 => 'ju', 'shan', 'jia', 'xuan', 'zha', 'bing', 'nie', 'zheng', 'yong', 'jing', 'quan', 'teng', 'tong', 'yi', 'jie', 'wei',
  0xD0 => 'hui', 'tan', 'yang', 'chi', 'zhi', 'hen', 'ya', 'mei', 'dou', 'jing', 'xiao', 'tong', 'tu', 'mang', 'pi', 'xiao',
  0xE0 => 'suan', 'fu', 'li', 'zhi', 'cuo', 'duo', 'wu', 'sha', 'lao', 'shou', 'huan', 'xian', 'yi', 'beng', 'zhang', 'guan',
  0xF0 => 'tan', 'fei', 'ma', 'lin', 'chi', 'ji', 'tian', 'an', 'chi', 'bi', 'bi', 'min', 'gu', 'dui', 'e', 'wei',
];
